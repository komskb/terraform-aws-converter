import logging
import os

import json
import time

import jwt
import requests


API_ENDPOINT = os.environ.get('API_ENDPOINT')
JWT_SECRET_KEY = os.environ.get('JWT_SECRET_KEY')

logger = logging.getLogger('ResultLambda')


def handler(event, context):
    header = {'Content-Type': 'application/json'}

    iat = int(round(time.time()))
    payload = {
        'exp': iat + (30 * 60),
    }
    token = jwt.encode(payload, JWT_SECRET_KEY, algorithm='HS256').decode('utf-8')
    try:
        data = {
            'token': token,
            'status': event['detail']['status'],
            'user_metadata': event['detail']['userMetadata'],
            'timestamp': event['detail']['timestamp'],
            'account_id': event['detail']['accountId'],
            'queue': event['detail']['queue'],
            'job_id': event['detail']['jobId'],
            'outputs': [],
        }

        if data['status'] == 'COMPLETE':
            for item in event['detail']['outputGroupDetails']:
                data['outputs'].append({
                    'path': item['outputDetails'][0]['outputFilePaths'][0],
                    'duration': item['outputDetails'][0]['durationInMs'],
                    'width': item['outputDetails'][0]['videoDetails']['widthInPx'],
                    'height': item['outputDetails'][0]['videoDetails']['heightInPx'],
                })
            url = '{}/success'.format(API_ENDPOINT)
        else:
            data['error_code'] = event['detail']['errorCode']
            data['error_message'] = event['detail']['errorMessage']
            url = '{}/fail'.format(API_ENDPOINT)
        requests.post(url, data=json.dumps(data), headers=header)
        print('MediaConvert Result Detail:\n{}'.format(data))
    except Exception as e:
        print('MediaConvert Result Error\n{}'.format(e))
    return
